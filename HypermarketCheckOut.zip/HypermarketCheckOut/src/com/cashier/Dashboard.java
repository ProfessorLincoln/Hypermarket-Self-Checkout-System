package com.cashier;
import java.io.File;  // Import the File class
import java.io.IOException;  // Import the IOException class to handle errors
import java.util.ArrayList;
import java.util.LinkedList;
import java.awt.Dimension;
import java.awt.Point;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.JTable;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;

class CustomerInformation{
	 
	private String custId;
	private String custIC;
	private String custName;
	private String counterPaid;
	private float totalPayment;
	private ArrayList<ItemInformation> itemInfo;
	

	public String getCustId() {
		return custId;
	}
	public void setCustId(String custId) {
		this.custId = custId;
	}
	public String getCustIC() {
		return custIC;
	}
	public void setCustIC(String custIC) {
		this.custIC = custIC;
	}
	public String getCounterPaid() {
		return counterPaid;
	}
	public void setCounterPaid(String counterPaid) {
		this.counterPaid = counterPaid;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public void getItemList(ArrayList<ItemInformation> itemInfoX) {
		
		this.itemInfo = itemInfoX;		
	}
	public ArrayList<ItemInformation> sendItemList() {
		
		return this.itemInfo;
	}
	public int totalItem() {
		return this.itemInfo.size();
	}
	public float totalPay() {
		totalPayment = 0;
		for (int counter = 0; counter < this.itemInfo.size(); counter++) { 		      
	         // System.out.println(this.itemInfo.get(counter)); 
			 ItemInformation xPrice = this.itemInfo.get(counter);
			 totalPayment = totalPayment + xPrice.getItemPrice();
	    }  
		return totalPayment;
	}
}
class ItemInformation {
	private String itemId;
	private String itemName;
	private float itemPrice;
	private String datePurchase;
	private int itemQuantity;
	private float itemUnitPrice;

	
	public String getItemId() {
		return itemId;
	}
	public void setItemId(String itemId) {
		this.itemId = itemId;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public float getItemPrice() {
		return itemPrice;
	}
	public void setItemPrice(float itemPrice) {
		this.itemPrice = itemPrice;
	}
	public float getItemUnitPrice() {
		return itemPrice;
	}
	public void setItemUnitPrice(float itemUnitPrice) {
		this.itemUnitPrice = itemUnitPrice;
	}
	public float getItemQuantity() {
		return itemQuantity;
	}
	public void setItemQuantity(int itemQuantity) {
		this.itemQuantity = itemQuantity;
	}
	
	public String getDatePurchase() {
		return datePurchase;
	}
	public void setDatePurchase(String datePurchase) {
		this.datePurchase = datePurchase;
	}
	
	
	
	
	
	
}
public class Dashboard {
	private JTextField txtItem;
	private JTextField textField_1;
	private static JLabel password1;
	private static JTextField username;
	private static JButton button;
	private static JPasswordField Password;
	private JTable table;
	private DefaultTableModel table_model;
	private JLabel lblSubTotalOutput,lblTotalItemOutput,lblTotalCounter;
	private JTextField customerName;
	private JTextField customerIC;
	private JTextField unitPrice;
	private JTextField quantity;
	private int glQuantity;
	private float glUnitPrice;
	private float glSubTotal;
	private LinkedList<CustomerInformation> que1;
	private LinkedList<CustomerInformation> que2;
	private LinkedList<CustomerInformation> que3;
	private int turn;
	
	
	
	
	
	
	
	
	Dashboard(){
		vDashboard();
		turn = 1;
	}
	public void vDashboard() {
		
		
		//customer ac er
		//ArrayList<ItemInformation> purchasedItemsList = new ArrayList<CustomerInformation>();
		
	
		
		
	
		JFrame frame = new JFrame();
		JPanel panel = new JPanel();
		panel.setBackground(new Color(240, 248, 255));
		panel.setLayout(null);
		
		frame.setTitle("LOGIN PAGE");
		frame.setLocation(new Point(10, 10));
		frame.getContentPane().add(panel);
		
		JButton btnAddItem = new JButton("Add Item");
		
		btnAddItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//Product product = new Product(table_model,table,lblSubTotalOutput,lblTotalItemOutput);
				
				addItem();
				
				
			}
		});
		btnAddItem.setFont(new Font("Lucida Grande", Font.BOLD, 19));
		btnAddItem.setForeground(Color.GREEN);
		btnAddItem.setBackground(new Color(128, 0, 128));
		btnAddItem.setBounds(812, 97, 117, 94);
		panel.add(btnAddItem);
		
		JButton btnPrint = new JButton("New Customer");
		btnPrint.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				newcustomer();
				
			}
		});
		btnPrint.setBounds(691, 97, 117, 94);
		panel.add(btnPrint);
		
		JLabel lblSubTotal = new JLabel("Sub Total :");
		lblSubTotal.setFont(new Font("Lucida Grande", Font.PLAIN, 24));
		lblSubTotal.setBounds(37, 428, 139, 40);
		panel.add(lblSubTotal);
		
		JLabel lblPointOfSales = new JLabel("Hypermarket Self Checkout");
		lblPointOfSales.setFont(new Font("Lucida Grande", Font.PLAIN, 36));
		lblPointOfSales.setForeground(Color.RED);
		lblPointOfSales.setBounds(27, 6, 602, 51);
		panel.add(lblPointOfSales);
		
		JPanel panelTitle = new JPanel();
		panelTitle.setBackground(Color.ORANGE);
		panelTitle.setBounds(6, 6, 988, 66);
		panel.add(panelTitle);
		
		//lable sub total
		lblSubTotalOutput = new JLabel("0.00");
		lblSubTotalOutput.setFont(new Font("Lucida Grande", Font.PLAIN, 24));
		lblSubTotalOutput.setBounds(162, 428, 125, 40);
		panel.add(lblSubTotalOutput);
		
		
		JLabel lblTotalItem = new JLabel("Total Item :");
		lblTotalItem.setFont(new Font("Lucida Grande", Font.PLAIN, 24));
		lblTotalItem.setBounds(279, 428, 153, 40);
		panel.add(lblTotalItem);
		
		//lable jumlah item
		lblTotalItemOutput = new JLabel("0");
		lblTotalItemOutput.setFont(new Font("Lucida Grande", Font.PLAIN, 24));
		lblTotalItemOutput.setBounds(444, 428, 43, 40);
		panel.add(lblTotalItemOutput);
		
		
		
		JLabel lblOrderList = new JLabel("Order List");
		lblOrderList.setForeground(new Color(128, 0, 128));
		lblOrderList.setFont(new Font("Lucida Grande", Font.PLAIN, 24));
		lblOrderList.setBounds(26, 84, 139, 40);
		panel.add(lblOrderList);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(27, 222, 753, 194);
		panel.add(scrollPane);
		
		
		String column_names[]= {"Item","Quantity","Unit Price","Price"};
		 table_model =new DefaultTableModel(column_names,0);
		
		table = new JTable(table_model);
		scrollPane.setViewportView(table);
		
		customerName = new JTextField();
		customerName.setBounds(132, 119, 285, 26);
		panel.add(customerName);
		customerName.setColumns(10);
		
		JLabel lblCustomerName = new JLabel("Customer Name");
		lblCustomerName.setBounds(27, 124, 110, 16);
		panel.add(lblCustomerName);
		
		customerIC = new JTextField();
		customerIC.setColumns(10);
		customerIC.setBounds(549, 119, 130, 26);
		panel.add(customerIC);
		
		JLabel lblCustomerIc = new JLabel("Customer IC");
		lblCustomerIc.setBounds(446, 124, 110, 16);
		panel.add(lblCustomerIc);
		
		JLabel lblItemName = new JLabel("Item Name");
		lblItemName.setBounds(27, 157, 110, 16);
		panel.add(lblItemName);
		
		
		
		txtItem = new JTextField();
		txtItem.setColumns(10);
		txtItem.setBounds(132, 157, 285, 26);
		panel.add(txtItem);
		
		unitPrice = new JTextField();
		unitPrice.setColumns(10);
		unitPrice.setBounds(549, 157, 71, 26);
		panel.add(unitPrice);
		
		JLabel lblUnitPrice = new JLabel("Unit Price");
		lblUnitPrice.setBounds(444, 157, 110, 16);
		panel.add(lblUnitPrice);
		
		JLabel lblQuantity = new JLabel("Quantity");
		lblQuantity.setBounds(444, 194, 110, 16);
		panel.add(lblQuantity);
		
		quantity = new JTextField();
		quantity.setColumns(10);
		quantity.setBounds(549, 184, 71, 26);
		panel.add(quantity);
		
		JButton btnCheckOut = new JButton("CheckOut");
		btnCheckOut.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				checkOut();
			}
		});
		btnCheckOut.setBounds(812, 291, 117, 79);
		panel.add(btnCheckOut);
		
		JButton btnQueue = new JButton("Queue");
		btnQueue.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Qinfo qInfo = new Qinfo(que1,que2,que3,turn);
			}
		});
		btnQueue.setBounds(812, 376, 117, 79);
		panel.add(btnQueue);
		
		JLabel lblCounter = new JLabel("Counter :");
		lblCounter.setFont(new Font("Lucida Grande", Font.PLAIN, 24));
		lblCounter.setBounds(499, 428, 110, 40);
		panel.add(lblCounter);
		
		lblTotalCounter = new JLabel("0");
		lblTotalCounter.setFont(new Font("Lucida Grande", Font.PLAIN, 24));
		lblTotalCounter.setBounds(619, 428, 153, 40);
		panel.add(lblTotalCounter);
		frame.setSize(new Dimension(1000, 500));
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);		
		frame.setVisible(true);
		que1 = new LinkedList<CustomerInformation>();
		que2 = new LinkedList<CustomerInformation>();
		que3 = new LinkedList<CustomerInformation>();
		
	}
	/* reset all item and table */
	public void newcustomer() {
		lblTotalItemOutput.setText("0");
		lblSubTotalOutput.setText("0");
		customerName.setText("");
		customerIC.setText("");
		txtItem.setText("");
		quantity.setText("0");
		unitPrice.setText("0");
		
		
		DefaultTableModel table_model = (DefaultTableModel) table.getModel();
		table_model.setRowCount(0);
		
		//table.add(table_model);
		
		
	}
	/* Add item */
	public void addItem() {
		glQuantity = Integer.parseInt(quantity.getText());
		glUnitPrice = Float.parseFloat(unitPrice.getText()); //dapatkan unit price
		glSubTotal = (float)(glQuantity * glUnitPrice); //jumlah harga
		
		table_model.addRow(new Object[]{txtItem.getText(), glQuantity, String.format("%.2f",glUnitPrice),String.format("%.2f",glSubTotal)});
		float subtotal = 0;
		
		
		//calculate total item and subtotal
		 for (int i = 0; i < table.getRowCount(); i++) {  // Loop through the rows
	        // Record the 5th column value (index 4)
	        //columnData[i] = jTable1.getValueAt(i, 4); 
			 subtotal = subtotal + Float.parseFloat(table.getValueAt(i, 3).toString());
			 System.out.println(table.getValueAt(i, 3));
			 
			 
		 }
		 lblSubTotalOutput.setText(String.format("%.2f",subtotal));
		 lblTotalItemOutput.setText(String.valueOf(table.getRowCount()));
		 txtItem.setText("");
		 quantity.setText("0");
		 unitPrice.setText("0");
		  
		 
		 
	}
	public void checkOut() {
		//array list
		int checkoutQuantity = 0;
		float checkoutUnitPrice = 0;
		float checkoutSubTotal = 0;
		String checkoutItemName = "";
				
		ArrayList<ItemInformation> purchasedItem = new ArrayList<ItemInformation>();
		
		for (int i = 0; i < table.getRowCount(); i++) {  // Loop through the rows
	        // Record the 5th column value (index 4)
	        //columnData[i] = jTable1.getValueAt(i, 4); 
			 checkoutQuantity = Integer.parseInt(table.getValueAt(i, 1).toString()); 
			 checkoutUnitPrice = Float.parseFloat(table.getValueAt(i, 2).toString());  
			 checkoutSubTotal = Float.parseFloat(table.getValueAt(i, 3).toString()); 
			 checkoutItemName = table.getValueAt(i, 0).toString();
			 
			 ItemInformation ItemInfo = new ItemInformation();
			 ItemInfo.setItemName(checkoutItemName);
			 ItemInfo.setItemPrice(checkoutSubTotal);
			 ItemInfo.setItemUnitPrice(checkoutUnitPrice);
			 ItemInfo.setItemQuantity(checkoutQuantity);
			 
			 //ItemInfo.setCustName(customerName.getText());
			 purchasedItem.add(ItemInfo);			 
			 //System.out.println(table.getValueAt(i, 3));
			 
		}
		
		CustomerInformation cust = new CustomerInformation();
		cust.getItemList(purchasedItem);
		cust.setCustName(customerName.getText());
		cust.setCustIC(customerIC.getText());
	
		int totalItem = cust.totalItem();
		if(totalItem <= 5) {
			//kalau barang kurang atau sama dengan 5 pergi kaunter 1 atau \2
			if(this.turn == 1) {
				que1.add(cust);
				System.out.println("Add Que1");
				lblTotalCounter.setText("Counter 1");
				this.turn = 2;
			}else if(this.turn == 2) {
				que2.add(cust);
				this.turn = 1;
				System.out.println("Add Que2");
				lblTotalCounter.setText("Counter 2");
			}
		}else{
			//barang lebih dari 5 akan masuk ke counter 3;
			que3.add(cust);
			//more than 5
			System.out.println("Add To Cpounter 3");
			lblTotalCounter.setText("Counter 3");
			
		}
		newcustomer();
		
		
		
		
		//que.add(cust);
		
		
		
		
		
		
	}

	
}


