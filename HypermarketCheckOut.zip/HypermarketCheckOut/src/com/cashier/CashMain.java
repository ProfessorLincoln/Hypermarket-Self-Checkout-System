package com.cashier;


public class CashMain {
	public static void main(String[] args) {
		System.out.print("Welcome");  
		//Welcome m = new Welcome();
		Dashboard d = new Dashboard();
		
		
	}

}

