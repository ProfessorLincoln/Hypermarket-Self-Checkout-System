package com.cashier;
import java.io.File;  // Import the File class
import java.io.FileNotFoundException;
import java.io.IOException;  // Import the IOException class to handle errors
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Scanner;
import java.awt.Dimension;
import java.awt.Point;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.JTable;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;
import javax.swing.JScrollPane;

public class Qinfo {
	private JTextField textField_1;
	private static JLabel password1;
	private static JTextField username;
	private static JButton button;
	private static JPasswordField Password;
	private JTable table;
	private JTable table2;
	private JTable table3;
	private DefaultTableModel table_model;
	private DefaultTableModel table_model_counter_2;
	private DefaultTableModel table_model_counter_3;
	private JTextField customerName;
	private JTextField customerIC;
	private JTextField quantity;
	private int glQuantity;
	private float glUnitPrice;
	private float glSubTotal;
	private JTextField lblsubTotal;
	private LinkedList<CustomerInformation> que1;
	private LinkedList<CustomerInformation> que2;
	private LinkedList<CustomerInformation> que3;
	private JTable tableCounter2;
	private JTable tableCounter3;
	private int currentQue;
	private int currentIndex; //index detail
	private String currentCustomer;
	private CustomerInformation detCust;
	private ArrayList<ItemInformation> purchasedItem;
	private int turn;
	
	
	
	
	Qinfo(LinkedList<CustomerInformation> counter1,LinkedList<CustomerInformation> counter2,LinkedList<CustomerInformation> counter3,int turn){
		vDashboard();
		this.que1 =counter1;
		this.que2 =counter2;
		this.que3 =counter3;
		reloadQue1();
		reloadQue2();
		reloadQue3();
		this.turn = 1;
		
	}
	public void vDashboard() {
		
		
		//customer ac er
		//ArrayList<ItemInformation> purchasedItemsList = new ArrayList<CustomerInformation>();
		
		
	
		JFrame frmCounterCustomerInfo = new JFrame();
		frmCounterCustomerInfo.setPreferredSize(new Dimension( 1020, 1020 ));
		JPanel panel = new JPanel();
		panel.setBackground(new Color(240, 248, 255));
		panel.setLayout(null);
		
		frmCounterCustomerInfo.setTitle("Counter Customer Info");
		frmCounterCustomerInfo.setLocation(new Point(10, 10));
		frmCounterCustomerInfo.getContentPane().add(panel);
		
		JButton btnPay = new JButton("Pay");
		btnPay.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				makePayment();
				//Pay pay = new Pay(table_model,table,lblSubTotalOutput,lblTotalItemOutput);
				
			}
		});
		btnPay.setBounds(821, 203, 108, 72);
		panel.add(btnPay);
		
		JLabel lblPointOfSales = new JLabel("Counter Customer Info");
		lblPointOfSales.setFont(new Font("Lucida Grande", Font.PLAIN, 36));
		lblPointOfSales.setForeground(Color.RED);
		lblPointOfSales.setBounds(27, 6, 602, 51);
		panel.add(lblPointOfSales);
		
		JPanel panelTitle = new JPanel();
		panelTitle.setBackground(Color.ORANGE);
		panelTitle.setBounds(6, 6, 988, 66);
		panel.add(panelTitle);
		
		
		
		JLabel lblOrderList = new JLabel("Counter 1");
		lblOrderList.setForeground(new Color(128, 0, 128));
		lblOrderList.setFont(new Font("Lucida Grande", Font.PLAIN, 24));
		lblOrderList.setBounds(26, 84, 139, 40);
		panel.add(lblOrderList);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(27, 123, 470, 161);
		panel.add(scrollPane);
		
		
		String column_names[]= {"Customer Name","Total Item","Sub Total"};
		table_model =new DefaultTableModel(column_names,0);
		
		String column_names_counter_2[]= {"Customer Name","Total Item","Sub Total"};
		table_model_counter_2 = new DefaultTableModel(column_names_counter_2,0);
		
		String column_names_counter_3[]= {"Customer Name","Total Item","Sub Total"};
		table_model_counter_3 = new DefaultTableModel(column_names_counter_3,0);
		
		table = new JTable(table_model);
		table.setRowSelectionAllowed(false);
		table.addMouseListener(
				new java.awt.event.MouseAdapter()
	            {
					public void mouseClicked(java.awt.event.MouseEvent e)

					{
						int indexNumber = table.getSelectedRow();
						
						
						int row=table.rowAtPoint(e.getPoint());
						int col= table.columnAtPoint(e.getPoint());
						//JOptionPane.showMessageDialog()
						//JOptionPane.showMessageDialog(null," Value in the cell clicked :"+ "" +table.getValueAt(row,col).toString());
						//JOptionPane.showMessageDialog(null," Index No :"+ "" + String.valueOf(indexNumber));
						detCust = que1.get(indexNumber);
						customerName.setText(detCust.getCustName());
						
						customerIC.setText(detCust.getCustIC());
						quantity.setText(String.valueOf(detCust.totalItem()));
						lblsubTotal.setText(String.valueOf(detCust.totalPay()));
						currentQue = 1;
						currentIndex = indexNumber;
						//customerIC.setText(detCust);
						//System.out.println(” Value in the cell clicked :”+ ” ” +table.getValueAt(row,col).toString());

					}
	            });
		scrollPane.setViewportView(table);
		
		
		
		customerName = new JTextField();
		customerName.setColumns(10);
		customerName.setBounds(624, 119, 258, 26);
		panel.add(customerName);
		
		customerIC = new JTextField();
		customerIC.setColumns(10);
		customerIC.setBounds(624, 157, 130, 26);
		panel.add(customerIC);
		
		quantity = new JTextField();
		quantity.setColumns(10);
		quantity.setBounds(624, 195, 130, 26);
		panel.add(quantity);
		
		
		JLabel lblCounter = new JLabel("Counter 2");
		lblCounter.setForeground(new Color(128, 0, 128));
		lblCounter.setFont(new Font("Lucida Grande", Font.PLAIN, 24));
		lblCounter.setBounds(27, 286, 139, 40);
		panel.add(lblCounter);
		
		JScrollPane scrollPaneCounter2 = new JScrollPane();
		scrollPaneCounter2.setBounds(27, 338, 470, 180);
		panel.add(scrollPaneCounter2);
		
		/* setup untuk table counter 2  */
		tableCounter2 = new JTable(table_model_counter_2);
		tableCounter2.setRowSelectionAllowed(false);
		tableCounter2.addMouseListener(
				new java.awt.event.MouseAdapter()
	            {
					public void mouseClicked(java.awt.event.MouseEvent e)

					{
						int indexNumber = tableCounter2.getSelectedRow();
						
						
						int row=tableCounter2.rowAtPoint(e.getPoint());
						int col= tableCounter2.columnAtPoint(e.getPoint());
						//JOptionPane.showMessageDialog()
						//JOptionPane.showMessageDialog(null," Value in the cell clicked :"+ "" +table.getValueAt(row,col).toString());
						//JOptionPane.showMessageDialog(null," Index No :"+ "" + String.valueOf(indexNumber));
						detCust = que2.get(indexNumber);
						customerName.setText(detCust.getCustName());
						customerIC.setText(detCust.getCustIC());
						quantity.setText(String.valueOf(detCust.totalItem()));
						lblsubTotal.setText(String.valueOf(detCust.totalPay()));
						currentQue = 2;
						currentIndex = indexNumber;
						//customerIC.setText(detCust);
						//System.out.println(” Value in the cell clicked :”+ ” ” +table.getValueAt(row,col).toString());

					}
	            });
		scrollPaneCounter2.setViewportView(tableCounter2);
		
		JLabel lblCounter_2 = new JLabel("Counter 3");
		lblCounter_2.setForeground(new Color(128, 0, 128));
		lblCounter_2.setFont(new Font("Lucida Grande", Font.PLAIN, 24));
		lblCounter_2.setBounds(26, 520, 139, 40);
		panel.add(lblCounter_2);
		
	
		
		JScrollPane scrollPaneCounter3 = new JScrollPane();
		scrollPaneCounter3.setBounds(27, 572, 470, 180);
		panel.add(scrollPaneCounter3);
		
		tableCounter3 = new JTable(table_model_counter_3);
		tableCounter3.setRowSelectionAllowed(false);
		tableCounter3.addMouseListener(
				new java.awt.event.MouseAdapter()
	            {
					public void mouseClicked(java.awt.event.MouseEvent e)

					{
						int indexNumber = tableCounter3.getSelectedRow();
						
						
						int row=tableCounter3.rowAtPoint(e.getPoint());
						int col= tableCounter3.columnAtPoint(e.getPoint());
						//JOptionPane.showMessageDialog()
						//JOptionPane.showMessageDialog(null," Value in the cell clicked :"+ "" +table.getValueAt(row,col).toString());
						//JOptionPane.showMessageDialog(null," Index No :"+ "" + String.valueOf(indexNumber));
						detCust = que3.get(indexNumber);
						customerName.setText(detCust.getCustName());
						customerIC.setText(detCust.getCustIC());
						quantity.setText(String.valueOf(detCust.totalItem()));
						lblsubTotal.setText(String.valueOf(detCust.totalPay()));
						currentQue = 3;
						currentIndex = indexNumber;
						//customerIC.setText(detCust);
						//System.out.println(” Value in the cell clicked :”+ ” ” +table.getValueAt(row,col).toString());

					}
	            });
		scrollPaneCounter3.setViewportView(tableCounter3);
		
		JButton btnRemoveCustomer = new JButton("Remove Customer");
		btnRemoveCustomer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				removeCustomer(currentIndex,currentQue);
			}
		});
		btnRemoveCustomer.setBounds(744, 286, 185, 93);
		panel.add(btnRemoveCustomer);
		
		JLabel lblCustomerName = new JLabel("Customer Name");
		lblCustomerName.setBounds(519, 124, 110, 16);
		panel.add(lblCustomerName);
		
		JLabel lblCustomerIc = new JLabel("Customer IC");
		lblCustomerIc.setBounds(519, 162, 110, 16);
		panel.add(lblCustomerIc);
		
		JLabel lblTotalPay = new JLabel("Total Item");
		lblTotalPay.setBounds(519, 203, 110, 16);
		panel.add(lblTotalPay);
		
		lblsubTotal = new JTextField();
		lblsubTotal.setColumns(10);
		lblsubTotal.setBounds(624, 233, 130, 26);
		panel.add(lblsubTotal);
		
		JLabel lblTotalPay_1 = new JLabel("Sub Total");
		lblTotalPay_1.setBounds(519, 238, 110, 16);
		panel.add(lblTotalPay_1);
		
		JButton btnLoadFile = new JButton("Load From File");
		btnLoadFile.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				reloadFromFile();
			}
		});
		btnLoadFile.setBounds(744, 396, 185, 93);
		panel.add(btnLoadFile);
		
		JButton btnReload = new JButton("Refresh");
		btnReload.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				reloadQue1();
				reloadQue2();
				reloadQue3();
			}
			
		});
		btnReload.setBounds(529, 286, 185, 93);
		panel.add(btnReload);
		frmCounterCustomerInfo.setSize(new Dimension(1000, 1500));
		frmCounterCustomerInfo.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);		
		frmCounterCustomerInfo.setVisible(true);
		
		
	}
	/* to remove customer from que */
	public void removeCustomer(int index,int currentCounter) {
		if(currentCounter == 1) {
			que1.remove(index);
			reloadQue1();
		}
		if(currentCounter == 2) {
			que2.remove(index);
			reloadQue2();
		}
		if(currentCounter == 3) {
			que3.remove(index);
			reloadQue3();
		}
		
			
		
	}
	public void reloadFromFile() {
		try {
		      File myObj = new File("orderlist.txt");
		      Scanner myReader = new Scanner(myObj);
		      boolean begin = false;	
		      String stage = "";
		      String currentCustomer = "";
		      
		      
		      while (myReader.hasNextLine()) {
		        String data = myReader.nextLine();
		       
		        //permulaan
		        System.out.println(data);
		        if(begin == false) {
		        	System.out.println(data + "begin false");
		        	if(data.equals("CUSTOMER INFO")){ //first row
		        		stage = "getCustomerDetail";
		        		begin = true;
		        		System.out.println(stage);
		        		purchasedItem = new ArrayList<ItemInformation>();
		        		
		        		
		        	}else {
		        		System.out.println("Other" + data + "x");
		        	}
		        	
		        }else {
		        	//next stage
		        	
		        	if(data.equals("CUSTOMER INFO")) {
		        		
		        		//ni untuk second customer
		        		String[] customerInfo = currentCustomer.split("#");
		        		String defcustomerName = "";
		        		String defcustomerIC = "";
		        		//split customer string
		        		for (String i : customerInfo) {
	        				 // System.out.println(i);
	        				String[] keyValueItem = i.split(":");
	        				if(keyValueItem[0].equals("NAME")) {
	        					 defcustomerName = keyValueItem[1];
	        				}
	        				if(keyValueItem[0].equals("IC")) {
	        					 defcustomerIC = keyValueItem[1];
	        				}
	        				
	        				
	        			}
		        		
		        		
		        		//spli current customer
		        		//System.out.println(purchasedItem);
		        		
		        		CustomerInformation cust = new CustomerInformation();
		        		cust.getItemList(purchasedItem);
		        		cust.setCustName(defcustomerName);
		        		cust.setCustIC(defcustomerIC);
		        		
		        		int totalItem = cust.totalItem();
		        		System.out.println("Total Item :" + String.valueOf(cust.totalItem()));
		        		if(totalItem <= 5) {
		        			//kalau barang kurang atau sama dengan 5 pergi kaunter 1 atau \2
		        			if(this.turn == 1) {
		        				que1.add(cust);
		        				System.out.println("Add Que1");
		        				//lblTotalCounter.setText("Counter 1");
		        				this.turn = 2;
		        			}else if(this.turn == 2) {
		        				que2.add(cust);
		        				this.turn = 1;
		        				System.out.println("Add Que2");
		        				
		        				//lblTotalCounter.setText("Counter 2");
		        			}
		        			
		        		}else{
		        			que3.add(cust);
		        			//more than 5
		        			System.out.println("Add To Cpounter 3");
		        			//lblTotalCounter.setText("Counter 3");
		        			
		        		}
		        		//get customerName;
		        		stage = "getCustomerDetail";
		        		purchasedItem = new ArrayList<ItemInformation>();
		        		
		        	}else {
		        		
		        		if(stage.equals("getCustomerDetail")) {
		        			//kalau dah detail before ni "CUSTOMER INFO" jadi next linen collect customer info
		        			currentCustomer = data;
		  
		        			System.out.println(stage);
		        			stage = "getItemInfo"; //move to collect 
		        			
		        		}else if(stage.equals("getItemInfo")) {
		        			
		        			System.out.println(stage);
		        			//kat sini baca item info
		        			
		        			
		        			String[] detailItem = data.split("#");
		        			String ItemName = "";
		        			int Quantity = 0;
		        			float UnitPrice = 0;
		        			
		        			for (String i : detailItem) {
		        				 // System.out.println(i);
		        				String[] keyValueItem = i.split(":");
		        				if(keyValueItem[0].equals("ITEM")) {
		        					ItemName = keyValueItem[1];
		        				}
		        				if(keyValueItem[0].equals("QUANTITY")) {
		        					Quantity = Integer.valueOf(keyValueItem[1]);
		        				}
		        				if(keyValueItem[0].equals("UNITPRICE")) {
		        					UnitPrice = Float.valueOf(keyValueItem[1]);
		        				}	
		        				
		        			}
		        			ItemInformation ItemInfo = new ItemInformation();
			       			ItemInfo.setItemName(ItemName);
			       			ItemInfo.setItemPrice(UnitPrice);
			       			ItemInfo.setItemQuantity(Quantity);
			       			
			       			//ItemInfo.setCustName(customerName.getText());
			       			purchasedItem.add(ItemInfo);	
			       			
			       			System.out.println(purchasedItem);
		        			
		        			
		        		}
		        		
		        	}
		        }
		        
		       
		        
		        System.out.println(data);
		      }
		      if(begin == true) {
		    	  /*ni loop last record dari text file
		    	   * daftar last rekod untuk masukkan ke dalam que
		    	   */
		    	  String[] customerInfo = currentCustomer.split("#");
	        		String defcustomerName = "";
	        		String defcustomerIC = "";
	        		//split customer string
	        		for (String i : customerInfo) {
      				 // System.out.println(i);
      				String[] keyValueItem = i.split(":");
      				if(keyValueItem[0].equals("NAME")) {
      					 defcustomerName = keyValueItem[1];
      				}
      				if(keyValueItem[0].equals("IC")) {
      					 defcustomerIC = keyValueItem[1];
      				}
      			}
	        	
	        	//spli current customer
	        	System.out.println(purchasedItem);
	        		
        		CustomerInformation cust = new CustomerInformation();
        		cust.getItemList(purchasedItem);
        		cust.setCustName(defcustomerName);
        		cust.setCustIC(defcustomerIC);
        		
        		int totalItem = cust.totalItem();
        		System.out.println("Total Item Last :" + String.valueOf(cust.totalItem()));
        		System.out.println("Turn :" + String.valueOf(this.turn));
        		if(totalItem <= 5) {
        			//kalau barang kurang atau sama dengan 5 pergi kaunter 1 atau \2
        			if(this.turn == 1) {
        				que1.add(cust);
        				System.out.println("Add Que1");
        				//lblTotalCounter.setText("Counter 1");
        				this.turn = 2;
        			}else if(this.turn == 2) {
        				que2.add(cust);
        				this.turn = 1;
        				System.out.println("Add Que2");
        				
        				//lblTotalCounter.setText("Counter 2");
        			}
        			
        		}else{
        			que3.add(cust);
        			//more than 5
        			System.out.println("Add To Cpounter 3");
        			//lblTotalCounter.setText("Counter 3");
        			
        		}
		    	
		    	  
		    	  
		      }
		      myReader.close();
		    } catch (FileNotFoundException e) {
		      System.out.println("An error occurred.");
		      e.printStackTrace();
		    }
		reloadQue1();
		reloadQue2();
		reloadQue3();
	}
	//reload table que 1
	public void reloadQue1() {
	
		this.table_model.setRowCount(0);
		for(int num=0; num < this.que1.size(); num++)
		{
    	  //System.out.println(que.get(num));
			CustomerInformation custInfo = this.que1.get(num);
			this.table_model.addRow(new Object[]{custInfo.getCustName(), custInfo.totalItem(), String.format("%.2f",custInfo.totalPay())});
  		
		}
		
	}
	//reload table que 2
	public void reloadQue2() {
		System.out.println(que2);
		this.table_model_counter_2.setRowCount(0);
		for(int num=0; num < this.que2.size(); num++)
		{
			System.out.println(num);
    	    System.out.println(que2.get(num));
			CustomerInformation custInfo = this.que2.get(num);
			System.out.println(custInfo.getCustName());
			this.table_model_counter_2.addRow(new Object[]{custInfo.getCustName(), custInfo.totalItem(), String.format("%.2f",custInfo.totalPay())});
  		
		}
	}
	public void reloadQue3() {
		this.table_model_counter_3.setRowCount(0);
		for(int num=0; num < this.que3.size(); num++)
		{
    	  //System.out.println(que.get(num));
			CustomerInformation custInfo = this.que3.get(num);
			this.table_model_counter_3.addRow(new Object[]{custInfo.getCustName(), custInfo.totalItem(), String.format("%.2f",custInfo.totalPay())});
  		
		}
	}
	public void makePayment() {
		//detCust = que1.get(indexNumber);
		 System.out.println(detCust.getCustName());
		 Pay pay = new Pay(detCust);
		 
		 
	}
}


